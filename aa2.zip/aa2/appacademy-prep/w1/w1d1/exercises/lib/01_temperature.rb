def ftoc(degrees)
  (degrees - 32) * 5/9.0
end

def ctof(degrees)
  (degrees * 9/5.0) + 32
end
