class Student
  attr_reader :first_name, :last_name, :name, :courses

  def initialize(first_name, last_name)
    @first_name, @last_name = first_name.capitalize, last_name.capitalize
    @courses = []
  end

  def name
    "#{first_name} #{last_name}"
  end

  def enroll(course)
    return if courses.include?(course)
    raise "class would cause conflict!" if has_conflict?(course)

    self.courses << course
    course.students << self
  end

  def has_conflict?(course)
    self.courses.any? do |enrolled_course|
      course.conflicts_with?(enrolled_course)
    end
  end

  def course_load
    schedule = Hash.new(0)
    self.courses.each do |course|
      schedule[course.department] += course.credits
    end

    schedule
  end
end
